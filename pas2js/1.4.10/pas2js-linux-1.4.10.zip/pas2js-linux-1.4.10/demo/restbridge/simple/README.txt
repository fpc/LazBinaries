
In order to run this demo, you must run one of the SQLDB REST bridge demos
as a server:

fpc/packages/fcl-web/example/restbridge
lazarus/components/fpweb/demo/restbridge/
lazarus/components/fpweb/demo/restmodule/

You need to know how it is configured (The port, base URL)

The servers are by default set up so the client requires authentication, 
so unless that was disabled, you need to know what user the demo is using to authenticate requests !
